# System Audit Logging and Retention
[FAKE SAMPLE - NOT REAL CONTENT]
Article ID: kb_audit_09

Audit records are immutable and retained for 7 years to satisfy regulatory compliance. Event types include AUTH_LOGIN, ROLE_CHANGE, DATA_EXPORT, and API_KEY_CYCLE.
