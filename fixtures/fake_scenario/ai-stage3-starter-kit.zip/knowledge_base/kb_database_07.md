# Database Connection Pooling and Timeouts
[FAKE SAMPLE - NOT REAL CONTENT]
Article ID: kb_database_07

Default connection pool max size is 20 connections per container instance. Idle connection timeout is 300 seconds. Pool exhaustion logs alert 'POOL_SATURATION'.
