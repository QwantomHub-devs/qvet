# Webhook Configuration and Retry Schedules
[FAKE SAMPLE - NOT REAL CONTENT]
Article ID: kb_webhook_03

Webhooks must respond with HTTP 200 within 5 seconds. Failed deliveries retry using exponential backoff: 30s, 5m, 30m, 2h, and 12h before dropping to dead-letter queue.
