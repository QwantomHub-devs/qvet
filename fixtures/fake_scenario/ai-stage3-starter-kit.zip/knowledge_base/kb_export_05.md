# Bulk Data Export Limits and Guidelines
[FAKE SAMPLE - NOT REAL CONTENT]
Article ID: kb_export_05

Exports exceeding 50,000 rows are processed asynchronously via background workers. A signed download URL is emailed to the requester within 15 minutes of completion.
