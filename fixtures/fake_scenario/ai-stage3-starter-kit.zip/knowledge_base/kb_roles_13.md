# Role-Based Access Control Matrix
[FAKE SAMPLE - NOT REAL CONTENT]
Article ID: kb_roles_13

Roles available: Owner, Admin, Member, and Viewer. Only Owners can delete workspaces or modify billing details. Admins can invite and remove Members.
