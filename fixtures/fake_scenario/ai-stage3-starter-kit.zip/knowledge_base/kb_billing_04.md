# Subscription Billing Cycles and Invoicing
[FAKE SAMPLE - NOT REAL CONTENT]
Article ID: kb_billing_04

Billing recurs on the 1st of each calendar month. Invoices are dispatched to the billing email on file. Payment retries occur automatically at 24h, 72h, and 120h intervals.
