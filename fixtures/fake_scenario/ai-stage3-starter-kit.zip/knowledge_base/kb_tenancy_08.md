# Multi-Tenant Data Isolation Architecture
[FAKE SAMPLE - NOT REAL CONTENT]
Article ID: kb_tenancy_08

Row-level tenant isolation is enforced through the tenant_id foreign key constraint. Cross-tenant queries are blocked at the database engine level via security definer policies.
