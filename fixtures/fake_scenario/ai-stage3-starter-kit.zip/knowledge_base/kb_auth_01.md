# API Authentication and Token Lifecycles
[FAKE SAMPLE - NOT REAL CONTENT]
Article ID: kb_auth_01

All API calls require a Bearer token generated via OAuth 2.0. Tokens expire strictly after 3600 seconds (1 hour). Refresh tokens are single-use and rotate on every renewal.
