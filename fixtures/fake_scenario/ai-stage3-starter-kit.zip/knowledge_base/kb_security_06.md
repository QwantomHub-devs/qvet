# API Key Rotation and Revocation
[FAKE SAMPLE - NOT REAL CONTENT]
Article ID: kb_security_06

To rotate API keys without downtime, create a secondary key in the admin portal, update your application configs, and revoke the primary key once traffic migrates.
