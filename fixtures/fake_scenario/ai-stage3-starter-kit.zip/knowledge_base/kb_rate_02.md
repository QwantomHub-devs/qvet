# Rate Limiting and Throttling Policies
[FAKE SAMPLE - NOT REAL CONTENT]
Article ID: kb_rate_02

Standard tier allows 100 requests per minute per IP. Pro tier allows 1,000 requests per minute. Exceeding limits returns HTTP 429 with Retry-After header indicating wait seconds.
