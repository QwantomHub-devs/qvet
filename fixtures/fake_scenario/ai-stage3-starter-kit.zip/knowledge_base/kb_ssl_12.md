# Custom Domain SSL Certificate Provisioning
[FAKE SAMPLE - NOT REAL CONTENT]
Article ID: kb_ssl_12

Custom domain certificates are auto-issued via Let's Encrypt using DNS-01 or HTTP-01 challenges. Renewals trigger automatically 30 days prior to expiration.
