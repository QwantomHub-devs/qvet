# Disaster Recovery and Snapshot Schedules
[FAKE SAMPLE - NOT REAL CONTENT]
Article ID: kb_backup_14

Point-in-time recovery is supported up to 14 days in the past. Full database snapshots execute daily at 02:00 UTC and replicate across two secondary geographic zones.
