# AI Track Stage 3: Practical Project Starter Kit
[FAKE SAMPLE - NOT REAL CONTENT FOR PRODUCTION TESTING]

## Overview
You have 5 hours (with up to 30 minutes of optional paused break) to complete:
- **Part A:** Multi-class priority classifier on customer support tickets (40 pts)
  - Submit `predictions.csv` with columns: `ticket_id,priority`
- **Part B:** RAG pipeline over internal knowledge base articles (40 pts)
  - Submit `retrieval.json` matching the provided template
- **Part C:** Codebase & Jupyter Notebook reproducibility (10 pts)
  - Submit `notebook.ipynb` and `code.zip`
- **Part D:** Technical Write-up (10 pts)
  - Submit `writeup.pdf` or `writeup.md` (maximum 2 pages / 1,000 words)

## Datasets Provided
- `data/train.csv`: 200 labeled support tickets (`ticket_id,subject,body,priority`)
- `data/practice_tickets.csv`: 40 unlabeled tickets for testing practice grading runs (up to 10 runs)
- `data/test_tickets.csv`: 60 unlabeled tickets for final evaluation
- `knowledge_base/`: 15 Markdown knowledge base articles
- `evaluation_queries.json`: 20 evaluation queries for Part B RAG pipeline

## Submission Templates
See `templates/predictions_template.csv` and `templates/retrieval_template.json`.
